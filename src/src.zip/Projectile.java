public class Projectile{
  private double positionX;
  private double postionY;
}